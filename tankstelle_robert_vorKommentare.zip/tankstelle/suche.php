<html>
    <head>
        <meta charset="UTF-8">
        <title>Tankstellenverwaltung</title>
    </head>
    <body>
        <h1>Suche nach Kundennummer</h1>

        <form method= "GET" action="suchergebnis.php">
            <label for="suche">Kundenummer:</label>
            <input type="search" name="suche">
            <button type="submit">Suchen</button>
            <button type="button" onclick="location.href = 'suche.php';">Leeren</button>
        </form>
    </body>
</html>


