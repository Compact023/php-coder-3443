<?php    
    /**
     * Überprüft, ob der Request ein GET Request ist
     * @return bool
     */
    function isGetRequest() : bool {
        return ($_SERVER['REQUEST_METHOD'] === 'GET');
    }
    
    /**
     * Liest Parameterwert aus dem GET Formular aus oder gibt einen Standard-Wert zurück.
     * Zusätzlich kann der Wert auch getrimmt werden.
     * 
     * @param string $fieldName FeldName (Parametername)
     * @param type $defaultValue Standardwert
     * @param bool $doTrim Flag ob der Wert getrimmt werden soll
     * @return type
     */
    function formFieldValueGET(string $fieldName, $defaultValue, bool $doTrim = true) {
        $value = (isset($_GET[$fieldName]) ? $_GET[$fieldName] : $defaultValue);
        
        if ($doTrim) {
            return trim($value);
        }
        return $value;
    }
    
    
    /**
     * Funktion zum Validieren von Formulardaten
     * 
     * @param array $formData Formulardaten
     * @param array $validations Validierungen
     * @param array $valdationErrors Fehlermeldungen
     * @return bool
     */
    function validate(array $formData, array $validations, array &$valdationErrors) : bool {
        // Durchlaufe alle Felder und deren Validatoren
        foreach ($validations as $fieldName => $fieldValidations) {
            // Durchlaufe alle Validatoren eines einzelnen Feldes
            foreach ($fieldValidations as $validator => $validatorData) {
                switch ($validator) {
                    case 'not_empty':
                        if (empty($formData[$fieldName])) {
                            $valdationErrors[$fieldName] = $validatorData['error_msg'];
                        }
                        break;
                        
                    case 'min_length':
                        if (strlen($formData[$fieldName]) < $validatorData['min']) {
                            $valdationErrors[$fieldName] = $validatorData['error_msg'];
                        }
                        break;
                }
            }
        }
        
        return (count($valdationErrors) == 0);
    }
    