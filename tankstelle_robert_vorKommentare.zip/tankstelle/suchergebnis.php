<?php
require_once 'config.php';
require_once 'functions.php';

// "Alte" prozedurale Version zum Aufbauen einer DB-Verbindung
// $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
// "neue" objektorientierte Variante
$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

// Überprüfen, ob die Verbindung zur Datenbank nicht aufgebaut werden konnte
if (!$conn) {
    // "alte" Version: Ausführung beenden und Fehlermeldung ausgeben
    //die('Es konnte keine DB-Verbindung hergestellt werden ' . mysqli_connect_error());
    // "neue" Version:
    die('Es konnte keine DB-Verbindung hergestellt werden ' . $conn->connect_error);
}


// "alte" Version: Zeichensatz hinterlegen
//mysqli_set_charset($conn, DB_CHARSET);
// "neue" Version
$conn->set_charset(DB_CHARSET);

if (isGetRequest()) {
    // Übergebene Daten aus POST-Request auslesen und in Array speichern
    $formData = [
        'kunde' => formFieldValueGET('suche', '')
    ];
}
// SQL Statement
$query = "SELECT * FROM kunde"
        . " WHERE kunde_id like ?";

// "alte" Version: prepared Statement erstellen
//$stmt = mysqli_prepare($conn, $query);
// "neue" Version
$stmt = $conn->prepare($query);

// "alte" Version: ? durch Werte in prepared Statement ersetzen
// mysqli_stmt_bind_param($stmt, "i", $autorId);
// "neue" Version
$stmt->bind_param("i", $formData['kunde']);

// "alte" Version: prepared statement ausführen
// mysqli_stmt_execute($stmt);
// "neue" Version
$stmt->execute();

// "alte" Version: Ergebnisse von der Datenbank holen
//$result = mysqli_stmt_get_result($stmt);
// "neue" Version
$result = $stmt->get_result();

$kunde = [];

// "alte" Version: Anzahl der Reihen im Resultat abfragen
// if ($result && mysqli_num_rows($result)) {...}
// "neue" Version
if ($result && $result->num_rows == 1) {

    // "alte" Version: Durchlaufen aller Datensätze und auslesen eines Datensatzes als assoziativen Arrays
    //while ($row = mysqli_fetch_assoc($result)) {...}
    // "neue" Version
    $kunde = $result->fetch_object();
} else {
    echo '<p>Der Kunde wurde nicht gefunden oder ungültige Eingabe!<p>';
    die();
}


$query = "SELECT * FROM verbrauch"
        . " WHERE kunde_id like ?";

// "alte" Version: prepared Statement erstellen
//$stmt = mysqli_prepare($conn, $query);
// "neue" Version
$stmt = $conn->prepare($query);

// "alte" Version: ? durch Werte in prepared Statement ersetzen
// mysqli_stmt_bind_param($stmt, "i", $autorId);
// "neue" Version
$stmt->bind_param("i", $formData['kunde']);

// "alte" Version: prepared statement ausführen
// mysqli_stmt_execute($stmt);
// "neue" Version
$stmt->execute();

// "alte" Version: Ergebnisse von der Datenbank holen
//$result = mysqli_stmt_get_result($stmt);
// "neue" Version
$result = $stmt->get_result();

$verbraeuche = [];
$preis = [];


// "alte" Version: Anzahl der Reihen im Resultat abfragen
// if ($result && mysqli_num_rows($result)) {...}
// "neue" Version
if ($result && $result->num_rows > 0) {

    // "alte" Version: Durchlaufen aller Datensätze und auslesen eines Datensatzes als assoziativen Arrays
    //while ($row = mysqli_fetch_assoc($result)) {...}
    // "neue" Version
    while ($row = $result->fetch_object()) {
        $verbraeuche[] = $row->menge;
        $preis[] = $row->preis;
        
    }
    $treibstoffverbrauch = null;
    foreach ($verbraeuche as $verbrauch) {
        $treibstoffverbrauch += $verbrauch;
    }

    $gesamtpreis = null;
    foreach ($preis as $preis) {
        $gesamtpreis += $preis;
    }
}



// "alte" Version DB Verbindung beenden
// mysqli_close($conn);
// "neue" Version
$conn->close();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <main>
            <h1>Suchergebnis</h1>
            <table>
                <tr>
                    <td><strong>Kundennummer:</strong></td>
                    <td><?= $kunde->kunde_id ?></td>
                </tr>
                <tr>
                    <td><strong>Vorname:</strong></td>
                    <td><?= $kunde->vorname ?></td>
                </tr>
                <tr>
                    <td><strong>Nachname:</strong></td>
                    <td><?= $kunde->nachname ?></td>
                </tr>
                <tr>
                    <td><strong>Strasse:</strong></td>
                    <td><?= $kunde->strasse ?></td>
                </tr>
                <tr>
                    <td><strong>PLZ:</strong></td>
                    <td><?= $kunde->plz ?></td>
                </tr>
                <tr>
                    <td><strong>Ort:</strong></td>
                    <td><?= $kunde->ort ?></td>
                </tr>
                <tr>
                    <td><strong>Geburtsdatum:</strong></td>
                    <td><?= $kunde->geburtsdatum ?></td>
                </tr>
                 <tr>
                     <td><br></td>
                    <td><br></td>
                </tr>
                <tr>
                    <td><strong>Treibstoffverbrauch:</strong></td>
                    <td><?= number_format($treibstoffverbrauch, 15, '.', ',') ?></td>
                </tr>
                <tr>
                    <td><strong>Gesamtpreis:</strong></td>
                    <td><?= number_format($gesamtpreis, 15, '.', ',') ?></td>
                </tr>
            </table>
        </main>
    </body>
</html>
